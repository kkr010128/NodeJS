const user = `김광래`;

module.exports = user; // 유저 변수 내보내기