const user = require("./user"); // user.js에서 user 변수 가져오기
const hello = require("./hello"); // hello.js에서 hello 함수 가져오기

hello(user); // 모듈에서 가져온 user 변수와 hellw 함수 사용하기