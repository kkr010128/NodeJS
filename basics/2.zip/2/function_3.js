let hi = function(){
    return '안녕하세요?';
}
console.log(hi());

// 화살표 함수
let hello = () => {return '안녕하세요?'};
console.log(hello());


// 더 간단하게
let hi_hello = () => '안녕하세요?';
console.log(hi());

// 화살표 함수에서 매개변수 가 있을 경우 어떻게 더 간단하게 표현하는지 문제 출제