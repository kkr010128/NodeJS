function greeting(name){ // 매개변수를 받음(parameter)
    console.log(`${name}님 안녕하세요?`);
}

greeting("김광래"); // 인수를 넘김(argument)