let num = 10; // 변수 선언
let num2 = 20; // var로도 가능하나, 여러 문제로 인해 let을 많이 사용함

console.log(num + "과" + num2 + "를 더하면" + (num+num2) + "입니다.");
console.log(`${num}과 ${num2}를 더하면 ${num+num2}입니다`); // 백틱 사용 시 변수를 간단하게 불러올 수 있음