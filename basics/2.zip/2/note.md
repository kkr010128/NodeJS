### __dirname : 현재 모듈이 있는 폴더 이름을 가져옴
### __filename : 현재 모듈 파일의 이름을 가져 옴


### TIMER FUNCTION
```js
setTimeout 함수는 지정한 시간이 지난 후에 함수 안의 내용을 실행

setInterval 함수는 지정한 시간마다 함수 안의 내용을 실행

clearInterval 함수는 setInterval 함수로 반복 실행하던 것을 멈춘다
```

### 유저의 입력을 받으려면 readline 모듈을 사용할 수 있다.