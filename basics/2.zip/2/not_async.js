function printA(){
    console.log(`A`);
}
function printB(){
    console.log(`B`);
}
function printC(){
    console.log(`C`);
}

printA();
printB();
printC();